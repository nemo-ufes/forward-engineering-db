package fillDB;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import factory.Util;

public class FillSupplyContract {

	private Parameters param;
	private int pkContract;
	private Statement stmOTpCC;
	private Statement stmOTpK;
	
	private ArrayList<Integer> corporateCustomers;
	private ArrayList<Integer> personalCustomers;
	private ArrayList<Integer> contractors;
	
	public FillSupplyContract(Statement stmOTpCC, Statement stmOTpK, Parameters param) throws SQLException{
		this.param = param;
		this.stmOTpCC = stmOTpCC;
		this.stmOTpK = stmOTpK;
		
		ResultSet rs = this.stmOTpCC.executeQuery("select max(supply_contract_id) next_id from supply_contract");
		rs.next();
		pkContract = rs.getInt(1) + 1;
	}
	
	public void setCorporateCustomersID(ArrayList<Integer> ids) {
		this.corporateCustomers = ids;
	}
	
	public void setPersonalCustomersID(ArrayList<Integer> ids) {
		this.personalCustomers = ids;
	}
	
	public void setContractorsID(ArrayList<Integer> ids) {
		this.contractors = ids;
	}
	
	public void fill() throws SQLException{
		System.out.println("STATUS ---> Filling supply_contract.");
		int quantityContract = param.getAmtContractPerRole();
		
		while ( quantityContract > 0) {
			fillSupplyContractContractor( );
			fillSupplyContractCorporateCustomer( );
			fillSupplyContractPersonalCustomer( );
			quantityContract--;
		}
		
		System.out.println("STATUS ---> supply_contract completed.");
	}
	
	private void fillSupplyContractContractor( ) throws SQLException {
		StringBuilder script = new StringBuilder();
		int sizeCC = corporateCustomers.size();
		int sizePC = personalCustomers.size();
		int prob;
		int pos;
		int val;
		boolean first = true;
		
		//contractors
		for (int contractor_id : contractors) {
			if(first) {
				script.append("INSERT INTO supply_contract (supply_contract_id, organization_customer_id, person_id, organization_id, contract_value) VALUES (");
					
				script.append(pkContract); //supply_contract_id
				script.append(",");
					
				prob = Util.getInstance().getRandomInt(100);//0..99
				if(prob < 50) {
					//corporateCustomers
					pos = Util.getInstance().getRandomInt(sizeCC);
					script.append( corporateCustomers.get(pos));//organization_customer_id
					script.append(",");
					script.append("null" );//person_id
				}else {
					//personalCustomers
					pos = Util.getInstance().getRandomInt(sizePC);
					script.append( "null" );//organization_customer_id
					script.append(",");
					script.append( personalCustomers.get(pos) );//person_id
				}
					
				script.append(",");
				script.append( contractor_id );//organization_id
				script.append(",");
				val = Util.getInstance().getRandomInt(500) * 1000;
				script.append(val );//contract_value	
				script.append(")\n     ");
				first = false;
			}else {
				script.append(", (");
				script.append(pkContract); //supply_contract_id
				script.append(",");
					
				prob = Util.getInstance().getRandomInt(100);//0..99
				if(prob < 50) {
					//corporateCustomers
					pos = Util.getInstance().getRandomInt(sizeCC);
					script.append( corporateCustomers.get(pos));//organization_customer_id
					script.append(",");
					script.append("null" );//person_id
				}else {
					//personalCustomers
					pos = Util.getInstance().getRandomInt(sizePC);
					script.append( "null" );//organization_customer_id
					script.append(",");
					script.append( personalCustomers.get(pos) );//person_id
				}
					
				script.append(",");
				script.append( contractor_id );//organization_id
				script.append(",");
				val = Util.getInstance().getRandomInt(500) * 1000;
				script.append(val );//contract_value	
				script.append(")\n     ");
			}
			
			if((pkContract % param.getAmountOfInsertPerTransaction()) == 0) {
				script.append(";");
				try{
					stmOTpCC.executeUpdate(script.toString());
				}
				catch(SQLException e) {
					System.out.println("ERROR: Error inserting into SUPPLY_CONTRACT (OTpCC). 1[FillSupplyContract.fillSupplyContractContractor]");
					System.out.println(script.toString());
					throw e;
				}
				try{
					stmOTpK.executeUpdate(script.toString());
				}
				catch(SQLException e) {
					System.out.println("ERROR: Error inserting into SUPPLY_CONTRACT (OTpK). 1[FillSupplyContract.fillSupplyContractContractor]");
					System.out.println(script.toString());
					throw e;
				}
				
				
				script = new StringBuilder();
				first = true;
			}
			pkContract++;
		}
		
		if(script.length() > 0) {
			script.append(";");
			try{
				stmOTpCC.executeUpdate(script.toString());
			}
			catch(SQLException e) {
				System.out.println("ERROR: Error inserting into SUPPLY_CONTRACT (OTpCC). 2[FillSupplyContract.fillSupplyContractContractor]");
				System.out.println(script.toString());
				throw e;
			}
			try{
				stmOTpK.executeUpdate(script.toString());
			}
			catch(SQLException e) {
				System.out.println("ERROR: Error inserting into SUPPLY_CONTRACT (OTpK). 2[FillSupplyContract.fillSupplyContractContractor]");
				System.out.println(script.toString());
				throw e;
			}
			script = new StringBuilder();
		}
	}
	
	private void fillSupplyContractCorporateCustomer( ) throws SQLException {
		StringBuilder script = new StringBuilder();
		int sizeC = contractors.size();
		int pos;
		int val;
		boolean first = true;
		
		//corporateCustomers
		for (int corporateCustomer_id : corporateCustomers) {
			if(first) {
				script.append("INSERT INTO supply_contract (supply_contract_id, organization_customer_id, person_id, organization_id, contract_value) VALUES (");
					
				script.append(pkContract); //supply_contract_id
				script.append(",");
				script.append( corporateCustomer_id);//organization_customer_id
				script.append(",");
				script.append("null" );//person_id
				script.append(",");
				pos = Util.getInstance().getRandomInt(sizeC);
				script.append( contractors.get(pos) );//organization_id
				script.append(",");
				val = Util.getInstance().getRandomInt(500) * 1000;
				script.append(val );//contract_value	
				script.append(")\n     ");
				first = false;
			}else {
				script.append(", (");
				script.append(pkContract); //supply_contract_id
				script.append(",");
				script.append( corporateCustomer_id);//organization_customer_id
				script.append(",");
				script.append("null" );//person_id
				script.append(",");
				pos = Util.getInstance().getRandomInt(sizeC);
				script.append( contractors.get(pos) );//organization_id
				script.append(",");
				val = Util.getInstance().getRandomInt(500) * 1000;
				script.append(val );//contract_value	
				script.append(")\n     ");
			}
			
			if((pkContract % param.getAmountOfInsertPerTransaction()) == 0) {
				script.append(";");
				try{
					stmOTpCC.executeUpdate(script.toString());
				}
				catch(SQLException e) {
					System.out.println("ERROR: Error inserting into SUPPLY_CONTRACT (OTpCC). [FillSupplyContract.fillSupplyContractCorporateCustomer]");
					System.out.println(script.toString());
					throw e;
				}
				try{
					stmOTpK.executeUpdate(script.toString());
				}
				catch(SQLException e) {
					System.out.println("ERROR: Error inserting into SUPPLY_CONTRACT (OTpK). [FillSupplyContract.fillSupplyContractCorporateCustomer]");
					System.out.println(script.toString());
					throw e;
				}
				script = new StringBuilder();
				first = true;
			}
			
			pkContract++;
		}
		
		if(script.length() > 0) {
			script.append(";");
			try{
				stmOTpCC.executeUpdate(script.toString());
			}
			catch(SQLException e) {
				System.out.println("ERROR: Error inserting into SUPPLY_CONTRACT (OTpCC). [FillSupplyContract.fillSupplyContractCorporateCustomer]");
				System.out.println(script.toString());
				throw e;
			}
			try{
				stmOTpK.executeUpdate(script.toString());
			}
			catch(SQLException e) {
				System.out.println("ERROR: Error inserting into SUPPLY_CONTRACT (OTpK). [FillSupplyContract.fillSupplyContractCorporateCustomer]");
				System.out.println(script.toString());
				throw e;
			}
			script = new StringBuilder();
		}
	}
	
	private void fillSupplyContractPersonalCustomer( ) throws SQLException {
		StringBuilder script = new StringBuilder();
		int sizeC = contractors.size();
		int pos;
		int val;
		boolean first = true;
		
		//personalCustomers
		for (int personCustomer_id : personalCustomers) {
			if(first) {
				script.append("INSERT INTO supply_contract (supply_contract_id, organization_customer_id, person_id, organization_id, contract_value) VALUES (");
					
				script.append(pkContract); //supply_contract_id
				script.append(",");
				script.append( "null" );//organization_customer_id
				script.append(",");
				script.append( personCustomer_id );//person_id
				script.append(",");
				pos = Util.getInstance().getRandomInt(sizeC);
				script.append( contractors.get(pos) );//organization_id
				script.append(",");
				val = Util.getInstance().getRandomInt(500) * 1000;
				script.append(val );//contract_value	
				script.append(")\n     ");
				first = false;
			}else {
				script.append(", (");
				script.append(pkContract); //supply_contract_id
				script.append(",");
				script.append( "null" );//organization_customer_id
				script.append(",");
				script.append( personCustomer_id );//person_id
				script.append(",");
				pos = Util.getInstance().getRandomInt(sizeC);
				script.append( contractors.get(pos) );//organization_id
				script.append(",");
				val = Util.getInstance().getRandomInt(500) * 1000;
				script.append(val );//contract_value	
				script.append(")\n     ");
			}
			
			if((pkContract % param.getAmountOfInsertPerTransaction()) == 0) {
				script.append(";");
				try{
					stmOTpCC.executeUpdate(script.toString());
				}
				catch(SQLException e) {
					System.out.println("ERROR: Error inserting into SUPPLY_CONTRACT (OTpCC). [FillSupplyContract.fillSupplyContractPersonalCustomer]");
					System.out.println(script.toString());
					throw e;
				}
				try{
					stmOTpK.executeUpdate(script.toString());
				}
				catch(SQLException e) {
					System.out.println("ERROR: Error inserting into SUPPLY_CONTRACT (OTpK). [FillSupplyContract.fillSupplyContractPersonalCustomer]");
					System.out.println(script.toString());
					throw e;
				}
				script = new StringBuilder();
				first = true;
			}
			pkContract++;
		}
		
		if(script.length() > 0) {
			script.append(";");
			try{
				stmOTpCC.executeUpdate(script.toString());
			}
			catch(SQLException e) {
				System.out.println("ERROR: Error inserting into SUPPLY_CONTRACT (OTpCC). [FillSupplyContract.fillSupplyContractPersonalCustomer]");
				System.out.println(script.toString());
				throw e;
			}
			try{
				stmOTpK.executeUpdate(script.toString());
			}
			catch(SQLException e) {
				System.out.println("ERROR: Error inserting into SUPPLY_CONTRACT (OTpK). [FillSupplyContract.fillSupplyContractPersonalCustomer]");
				System.out.println(script.toString());
				throw e;
			}
			script = new StringBuilder();
		}
	}
}
