package fillDB;

import java.sql.Statement;
import java.sql.Connection;

public class FillDatabase {

	public static void fill(Parameters param) {
		FillOrganization fillOrganization;
		FillPerson fillPerson;
		FillSupplyContract fillSupplyContract;
		FillEmployment fillEmployment;
		FillEnrollment fillEnrollment;
		
		Connection connOTpK;
		Statement stmOTpK;
		Connection connOTpCC;
		Statement stmOTpCC;
		
		
		
		try {
			//connOTpCC = DataBaseConnection.getH2ConnectionOTpCC();
			connOTpCC = DataBaseConnection.getMySqlConnectionOTpCC();
			stmOTpCC = connOTpCC.createStatement();
			
			//connOTpK = DataBaseConnection.getH2ConnectionOTpK();
			connOTpK = DataBaseConnection.getMySqlConnectionOTpK();
			stmOTpK = connOTpK.createStatement();
			
			fillOrganization = new FillOrganization(stmOTpCC, stmOTpK, param);
			fillOrganization.fill();
			
			fillPerson = new FillPerson(stmOTpCC, stmOTpK, param);
			fillPerson.fill();
			
			fillSupplyContract = new FillSupplyContract(stmOTpCC, stmOTpK, param);
			fillSupplyContract.setContractorsID(fillOrganization.getContractorsID());
			fillSupplyContract.setCorporateCustomersID(fillOrganization.getCustomersID());
			fillSupplyContract.setPersonalCustomersID(fillPerson.getCustomersID());
			fillSupplyContract.fill();
			
			fillEmployment = new FillEmployment(stmOTpCC, stmOTpK, param);
			fillEmployment.setEmployeesID(fillPerson.getEmployeesID());
			fillEmployment.setOrganizationsID(fillOrganization.getOrganizationsID());
			fillEmployment.fill();
			
			fillEnrollment = new FillEnrollment(stmOTpCC, stmOTpK, param);
			fillEnrollment.setChilds(fillPerson.getChildsID());
			fillEnrollment.setSchoolsID(fillOrganization.getSchoolsID());
			fillEnrollment.fill();
			
		
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
