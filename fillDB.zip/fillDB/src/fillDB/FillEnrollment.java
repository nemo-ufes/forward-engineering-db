package fillDB;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import factory.Util;

public class FillEnrollment {

	private Parameters param;
	private int pkEnrollment;
	private Statement stmOTpCC;
	private Statement stmOTpK;
	private boolean first;
	
	private ArrayList<Integer> childs;
	private ArrayList<Integer> schools;
	
	public FillEnrollment(Statement stmOTpCC, Statement stmOTpK, Parameters param) throws SQLException{
		this.param = param;
		this.stmOTpCC = stmOTpCC;
		this.stmOTpK = stmOTpK;
		
		ResultSet rs = stmOTpCC.executeQuery("select max(enrollment_id) next_id from enrollment");
		rs.next();
		pkEnrollment = rs.getInt(1) + 1;
		first = true;
	}
	
	public void setChilds(ArrayList<Integer> ids) {
		this.childs = ids;
	}
	
	public void setSchoolsID(ArrayList<Integer> ids) {
		this.schools = ids;
	}
	
	public void fill() throws SQLException{
		StringBuilder script = new StringBuilder();
		int prob;
		
		System.out.println("STATUS ---> Filling enrollment.");
		
		first = true;
		for (int person_id : childs) {
			
			addEnrollmentScript(script, person_id);
			first = false;
			
			prob = Util.getInstance().getRandomInt(100);//0..99
			
			if(prob < param.getpctChildMoreEnrollment() ){
				pkEnrollment++;
				addEnrollmentScript(script, person_id);
			}
			
			if((pkEnrollment % param.getAmountOfInsertPerTransaction()) == 0) {
				script.append(";");
				try{
					stmOTpCC.executeUpdate(script.toString());
				}
				catch(SQLException e) {
					System.out.println("ERROR: Error inserting into ENROLLMENT (OTpCC). [FillEnrollment.fill]");
					System.out.println(script.toString());
					throw e;
				}
				try{
					stmOTpK.executeUpdate(script.toString());
				}
				catch(SQLException e) {
					System.out.println("ERROR: Error inserting into ENROLLMENT (OTpK). [FillEnrollment.fill]");
					System.out.println(script.toString());
					throw e;
				}
				script = new StringBuilder();
				first = true;
			}
			pkEnrollment++;
		}
		
		if(script.length() > 10) {
			script.append(";");
			try{
				stmOTpCC.executeUpdate(script.toString());
			}
			catch(SQLException e) {
				System.out.println("ERROR: Error inserting into ENROLLMENT (OTpCC). [FillEnrollment.fill]");
				System.out.println(script.toString());
				throw e;
			}
			try{
				stmOTpK.executeUpdate(script.toString());
			}
			catch(SQLException e) {
				System.out.println("ERROR: Error inserting into ENROLLMENT (OTpK). [FillEnrollment.fill]");
				System.out.println(script.toString());
				throw e;
			}
			script = new StringBuilder();
		}
		System.out.println("STATUS ---> enrollment completed.");
	}
	
	private void addEnrollmentScript(StringBuilder script, int person_id) {
		int sizeS = schools.size();
		int pos;
		int val;
		
		if(first) {
			script.append("INSERT INTO enrollment (enrollment_id, organization_id, person_id, grade) VALUES (");
			
			script.append( pkEnrollment ); //enrollment_id
			script.append(",");
			pos = Util.getInstance().getRandomInt(sizeS);
			script.append( schools.get(pos) );//organization_id
			script.append(",");
			script.append( person_id );//person_id
			script.append(",");
			val = Util.getInstance().getRandomInt(9) + 1 ;
			script.append(val );//contract_value	
			script.append(")\n     ");
		}else {
			script.append(", (");
			script.append( pkEnrollment ); //enrollment_id
			script.append(",");
			pos = Util.getInstance().getRandomInt(sizeS);
			script.append( schools.get(pos) );//organization_id
			script.append(",");
			script.append( person_id );//person_id
			script.append(",");
			val = Util.getInstance().getRandomInt(9) + 1 ;
			script.append(val );//contract_value	
			script.append(")\n     ");
		}
	}
}
