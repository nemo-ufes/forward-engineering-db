package fillDB;

public class Parameters {
	private int amountOfInsertPerTransaction = 100;
	
	private int amtOrganization = 1; //amount of organizations to be inserted (amtOrganization * 100)
	private int pctContractor = 1; //percentage of organizations that are contractors.
	private int pctCorporateCustomer = 1; //percentage of organizations that are customers.
	private int pctHospitalOrganization = 1; //percentage of organizations that are hospital. The rest is PrimarySchool.
	
	private int amtPerson = 1; //amount of organizations to be inserted (amtPerson * 100)
	private int pctBrazilianCitizen = 1; //percentage of people that are Brazilian.
	private int pctItalianCitizen = 1; //percentage of people that are Italian.
	private int pctBrazilianItalianCitizen = 1; //percentage of people that are Brazilian and ItalianCitizen.
	private int pctAdult = 1; //percentage of people that are adults.
	private int pctEmployee = 1; //percentage of adults that are employee.
	private int pctPersonalCustomer; //percentage of adults that are customers.
	
	public int amtContractPerRole = 1; // amount of contracts for each contractor, corporateCustomer and personalCustomer  
	//(amtContractPerRole * contractor + amtContractPerRole * corporateCustomer + amtContractPerRole * personalCustomer) 
	
	public int pctEmployeeMoreJobs = 1; //percentage of employees with more than one job.
	public int pctChildMoreEnrollment = 1; // percentage of children with more than one enrollment.

	public int getAmountOfInsertPerTransaction() {
		return this.amountOfInsertPerTransaction;
	}
	public void setAmountOfInsertPerTransaction(int amountOfInsertPerTransaction) {
		this.amountOfInsertPerTransaction = amountOfInsertPerTransaction;
	}
	public int getAmtOrganization() {
		return this.amtOrganization;
	}
	public void setAmtOrganization(int amtOrganization) {
		this.amtOrganization = amtOrganization;
	}
	public int getPctContractor() {
		return this.pctContractor;
	}
	public void setPctContractor(int pctContractor) {
		this.pctContractor = pctContractor;
	}
	public int getPctCorporateCustomer() {
		return this.pctCorporateCustomer;
	}
	public void setPctCorporateCustomer(int pctCorporateCustomer) {
		this.pctCorporateCustomer = pctCorporateCustomer;
	}
	public int getPctHospitalOrganization() {
		return this.pctHospitalOrganization;
	}
	public void setPctHospitalOrganization(int pctHospitalOrganization) {
		this.pctHospitalOrganization = pctHospitalOrganization;
	}
	public int getAmtPerson() {
		return this.amtPerson;
	}
	public void setAmtPerson(int amtPerson) {
		this.amtPerson = amtPerson;
	}
	public int getPctBrazilianCitizen() {
		return this.pctBrazilianCitizen;
	}
	public int getPctItalianCitizen() {
		return this.pctItalianCitizen;
	}
	public int getPctBrazilianItalianCitizen() {
		return this.pctBrazilianItalianCitizen;
	}
	public void setPctNationality(int pctBrazilianCitizen, int pctItalianCitizen, int pctBrazilianItalianCitizen) throws Exception {
		if( (pctBrazilianCitizen + pctItalianCitizen + pctBrazilianItalianCitizen ) > 100)
			throw new Exception("Sum of percentages greater than 100."); 
		
		this.pctBrazilianCitizen = pctBrazilianCitizen;
		this.pctItalianCitizen = pctItalianCitizen;
		this.pctBrazilianItalianCitizen = pctBrazilianItalianCitizen;
	}
	public int getPctAdult() {
		return this.pctAdult;
	}
	public void setPctAdult(int pctAdult) {
		this.pctAdult = pctAdult;
	}
	public int getPctEmployee() {
		return this.pctEmployee;
	}
	public void setPctEmployee(int pctEmployee) {
		this.pctEmployee = pctEmployee;
	}
	public int getAmtContractPerRole() {
		return this.amtContractPerRole;
	}
	public void setAmtContractPerRole(int amtContractPerRole) {
		this.amtContractPerRole = amtContractPerRole;
	}
	public int getPctEmployeeMoreJobs() {
		return this.pctEmployeeMoreJobs;
	}
	public void setPctEmployeeMoreJobs(int pctEmployeeMoreJobs) {
		this.pctEmployeeMoreJobs = pctEmployeeMoreJobs;
	}
	public int getpctChildMoreEnrollment() {
		return this.pctChildMoreEnrollment;
	}
	public void setPctChildMoreEnrollment(int pctChildMoreEnrollment) {
		this.pctChildMoreEnrollment = pctChildMoreEnrollment;
	}
	public int getPctPersonalCustomer() {
		return this.pctPersonalCustomer;
	}
	public void setPctPersonalCustomer(int pctPersonalCustomer) {
		this.pctPersonalCustomer = pctPersonalCustomer;
	}
	
}
