package fillDB;

import java.util.Date;

public class Main {

	public static void main(String[] args) {
		Date date1;
		Date date2;
		long dif;
		
		System.out.println("Starting fill process ....");
		
		try {
			date1 = new Date();
			
			Parameters param = new Parameters();
			
			param.setAmountOfInsertPerTransaction(1000);
	
			param.setAmtOrganization(50); //amount of organizations to be inserted (amtOrganization * setAmountOfInsertPerTransaction(...))
			param.setPctContractor(100);  //percentage of organizations that are contractors.
			param.setPctCorporateCustomer(80); //percentage of organizations that are customers.
			param.setPctHospitalOrganization(60); //percentage of organizations that are hospital. The rest is PrimarySchool.
			
			param.setAmtPerson(200); //amount of organizations to be inserted (amtPerson * setAmountOfInsertPerTransaction(...))
			param.setPctNationality(45, 45, 10); //percentage of people that are Brazilian, Italian, Brazilian and Italian at same time.
			param.setPctAdult(80); //percentage of people that are adults.
			param.setPctEmployee(80); //percentage of adults that are employee.
			param.setPctPersonalCustomer(100); //percentage of adults that are customers.
			
			param.setAmtContractPerRole(1); // amount of contracts for each contractor, corporateCustomer and personalCustomer   
			param.setPctEmployeeMoreJobs(30); //percentage of employees with more than one job.
			param.setPctChildMoreEnrollment(60); //percentage of children with more than one enrollment.
			
			FillDatabase.fill(param);
			
			date2 = new Date();
			
			dif = date2.getTime() - date1.getTime();
			
			System.out.println("Time to fill the databases (in miliseconds): " + dif);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

// time for 1.000 (organization) and 2.000 (person) = 717965