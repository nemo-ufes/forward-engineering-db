package fillDB;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import factory.Util;

public class FillEmployment {

	private Parameters param;
	private int pkEmployment;
	private Statement stmOTpCC;
	private Statement stmOTpK;
	private boolean first;
	
	private ArrayList<Integer> employees;
	private ArrayList<Integer> organizations;
	
	public FillEmployment(Statement stmOTpCC, Statement stmOTpK, Parameters param) throws SQLException{
		this.stmOTpCC = stmOTpCC;
		this.stmOTpK = stmOTpK;
		this.param = param;
		
		ResultSet rs = stmOTpCC.executeQuery("select max(employment_id) next_id from employment");
		rs.next();
		pkEmployment = rs.getInt(1) + 1;
		first = true;
	}
	
	public void setEmployeesID(ArrayList<Integer> ids) {
		this.employees = ids;
	}
	
	public void setOrganizationsID(ArrayList<Integer> ids) {
		this.organizations = ids;
	}
	
	public void fill( ) throws SQLException{
		StringBuilder script = new StringBuilder();
		int prob;
		
		System.out.println("STATUS ---> Filling employment.");
		
		first = true;
		for (int person_id : employees) {
			addEmploymentScript(script, person_id);
			first = false;
			
			prob = Util.getInstance().getRandomInt(101);//0..100
			if(prob <= param.getPctEmployeeMoreJobs() ){
				pkEmployment++;
				addEmploymentScript(script, person_id);
			}
			
			if((pkEmployment % param.getAmountOfInsertPerTransaction()) == 0) {
				script.append(";");
				try{
					stmOTpCC.executeUpdate(script.toString());
				}
				catch(SQLException e) {
					System.out.println("ERROR: Error inserting into EMPLOYMENT (OTpCC). [FillEmployment.fill]");
					System.out.println(script.toString());
					throw e;
				}
				try{
					stmOTpK.executeUpdate(script.toString());
				}
				catch(SQLException e) {
					System.out.println("ERROR: Error inserting into EMPLOYMENT (OTpK). [FillEmployment.fill]");
					System.out.println(script.toString());
					throw e;
				}
				script = new StringBuilder();
				first = true;
			}
			pkEmployment++;
		}
		
		if(script.length() > 10) {
			script.append(";");
			try{
				stmOTpCC.executeUpdate(script.toString());
			}
			catch(SQLException e) {
				System.out.println("ERROR: Error inserting into EMPLOYMENT (OTpCC). [FillEmployment.fill]");
				System.out.println(script.toString());
				throw e;
			}
			
			try{
				stmOTpK.executeUpdate(script.toString());
			}
			catch(SQLException e) {
				System.out.println("ERROR: Error inserting into EMPLOYMENT (OTpK). [FillEmployment.fill]");
				System.out.println(script.toString());
				throw e;
			}
			script = new StringBuilder();
		}
		System.out.println("STATUS ---> employment completed.");
	}
	
	private void addEmploymentScript(StringBuilder script, int person_id) {
		int sizeO = organizations.size();
		int pos;
		int val;
		
		if(first) {
			script.append("INSERT INTO employment (employment_id, organization_id, person_id, salary) VALUES (");
			
			script.append( pkEmployment ); //employment_id
			script.append(",");
			pos = Util.getInstance().getRandomInt(sizeO);
			script.append( organizations.get(pos) );//organization_id
			script.append(",");
			script.append( person_id );//person_id
			script.append(",");
			val = (Util.getInstance().getRandomInt(20) + 1) * 1000;
			script.append(val);//contract_value	
			script.append(")\n     ");
		}else {
			script.append(", (");
			script.append( pkEmployment ); //employment_id
			script.append(",");
			pos = Util.getInstance().getRandomInt(sizeO);
			script.append( organizations.get(pos) );//organization_id
			script.append(",");
			script.append( person_id );//person_id
			script.append(",");
			val = (Util.getInstance().getRandomInt(20) + 1) * 1000;
			script.append(val);//contract_value	
			script.append(")\n     ");
		}
	}
}
