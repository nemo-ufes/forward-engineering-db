package fillDB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DataBaseConnection {
	

	public static java.sql.Connection getH2ConnectionOTpCC() {
		return getConnectionForH2("otpcc_s", "sa", "sa");
	}
	
	public static java.sql.Connection getH2ConnectionOTpK() {
		return getConnectionForH2("otpK_s", "sa", "sa");
	}
	
	public static java.sql.Connection getMySqlConnectionOTpCC() {
		return getConnectionForMySql("otpcc_t", "root", "admin");
	}
	
	public static java.sql.Connection getMySqlConnectionOTpK() {
		return getConnectionForMySql("otpK_t", "root", "admin");
	}
	
	private static java.sql.Connection getConnectionForH2(String database, String username, String password) {
		Connection connection = null;

		try {
			// Carregando o JDBC Driver padr�o
			Class.forName("org.h2.Driver");

			// Configurando a nossa conex�o com um banco de dados//
			String url = "jdbc:h2:tcp://localhost/./"+database;

			connection = DriverManager.getConnection(url, username, password);
			
			// Testa sua conex�o//
			if (connection != null) {
				connection.setAutoCommit(true);
				System.out.println("STATUS--->Conectado em"+ database +" com sucesso!");
			} else {
				System.out.println("STATUS--->N�o foi possivel realizar conex�o");
			}

			return connection;

		} catch (ClassNotFoundException e) { // Driver n�o encontrado
			System.out.println("O driver expecificado nao foi encontrado." + e.toString());
			return null;
		} catch (SQLException e) {
			// N�o conseguindo se conectar ao banco
			System.out.println("Nao foi possivel conectar ao Banco de Dados."+ e.toString());
			return null;
		}
	}	
	
	private static java.sql.Connection getConnectionForMySql(String database, String username, String password) {
		Connection connection = null;

		try {
			// Carregando o JDBC Driver padr�o
			Class.forName("com.mysql.cj.jdbc.Driver");
			

			// Configurando a nossa conex�o com um banco de dados//
			String url = "jdbc:mysql://localhost:3306/"+database;

			connection = DriverManager.getConnection(url, username, password);

			// Testa sua conex�o//
			if (connection != null) {
				System.out.println("STATUS--->Conectado em"+ database +" com sucesso!");
			} else {
				System.out.println("STATUS--->N�o foi possivel realizar conex�o");
			}

			return connection;

		} catch (ClassNotFoundException e) { // Driver n�o encontrado
			System.out.println("O driver expecificado nao foi encontrado." + e.toString());
			return null;
		} catch (SQLException e) {
			// N�o conseguindo se conectar ao banco
			System.out.println("Nao foi possivel conectar ao Banco de Dados."+ e.toString());
			return null;
		}
	}

	// M�todo que fecha sua conex�o//
	public static boolean closeConnection(Connection connection) {
		try {
			connection.close();
			return true;
		} catch (SQLException e) {
			return false;
		}
	}


}
