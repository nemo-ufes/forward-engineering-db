package fillDB;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import classes.LifePhase;
import classes.Nationality;
import classes.Person;
import factory.Factory;

public class FillPerson {
	
	private Parameters param;
	private int pkPerson;
	private int pkNationality;
	private Statement stmOTpCC;
	private Statement stmOTpK;
	
	private StringBuilder scriptPerson;
	private StringBuilder scriptBrazilianCitizen;
	private StringBuilder scriptItalianCitizen;
	private StringBuilder scriptChild;
	private StringBuilder scriptAdult;
	private StringBuilder scriptEmployee;
	private StringBuilder scriptPersonalCustomer;
	private StringBuilder scriptOTpKPerson;
	private StringBuilder scriptOTpKNationality;
	
	private static ArrayList<Integer> brazilians;
	private static ArrayList<Integer> italians;
	private static ArrayList<Integer> childs;
	private static ArrayList<Integer> adults;
	private static ArrayList<Integer> customers;
	private static ArrayList<Integer> employees;

	public FillPerson(Statement stmOTpCC, Statement stmOTpK, Parameters param) throws SQLException{
		this.param = param;
		this.stmOTpCC = stmOTpCC;
		this.stmOTpK = stmOTpK;
		ResultSet rs;
		
		rs = stmOTpCC.executeQuery("select max(person_id) next_id from person");
		rs.next();
		pkPerson = rs.getInt(1) + 1;
		
		rs.close();
		rs = stmOTpK.executeQuery("select max(nationality_id) next_id from nationality");
		rs.next();
		pkNationality = rs.getInt(1) + 1;
		rs.close();
		
		brazilians = new ArrayList<Integer>();
		italians = new ArrayList<Integer>();
		childs = new ArrayList<Integer>();
		adults = new ArrayList<Integer>();
		customers = new ArrayList<Integer>();
		employees = new ArrayList<Integer>();
	}
	
	public ArrayList<Integer> getBraziliansID(){
		return brazilians;
	}
	
	public ArrayList<Integer> getItaliansID(){
		return italians;
	}
	
	public ArrayList<Integer> getChildsID(){
		return childs;
	}
	
	public ArrayList<Integer> getAdultsID(){
		return adults;
	}
	
	public ArrayList<Integer> getCustomersID(){
		return customers;
	}
	
	public ArrayList<Integer> getEmployeesID(){
		return employees;
	}
	
	public void fill() throws SQLException{
		if(param.getAmtPerson() > 0) {
			fillPerson();
		}else {
			fillArrays();
		}
	}
	
	private void fillArrays()throws SQLException{
		ResultSet rs;
		
		System.out.println("STATUS ---> Getting personal_customer.");
		rs = this.stmOTpCC.executeQuery("select person_id from personal_customer order by person_id");
		while(rs.next()) {
			customers.add(rs.getInt(1));
		}
		rs.close();
		
		System.out.println("STATUS ---> Getting employee.");
		rs = this.stmOTpCC.executeQuery("select person_id from employee order by person_id");
		while(rs.next()) {
			employees.add(rs.getInt(1));
		}
		rs.close();
		
		System.out.println("STATUS ---> Getting child.");
		rs = this.stmOTpCC.executeQuery("select person_id from child order by person_id");
		while(rs.next()) {
			childs.add(rs.getInt(1));
		}
		rs.close();
	}
	
	private void fillPerson() throws SQLException{
		int quantityPerson = param.getAmtPerson();
		System.out.println("STATUS ---> Filling person.");
		
		while (quantityPerson > 0) {
			
			pullScriptForPerson();
			
			try {
				if(scriptPerson.length() > 10)
					stmOTpCC.executeUpdate(scriptPerson.toString());
			}
			catch(SQLException e) {
				System.out.println("ERROR: Error inserting into PERSON (OTpCC). [FillPersonn.fillPerson()]");
				System.out.println(scriptPerson.toString());
				throw e;
			}
			
			try {
				if(scriptBrazilianCitizen.length() > 10)
					stmOTpCC.executeUpdate(scriptBrazilianCitizen.toString());
			}
			catch(SQLException e) {
				System.out.println("ERROR: Error inserting into BRAZILIAN_CITIZEN (OTpCC). [FillPersonn.fillPerson()]");
				System.out.println(scriptBrazilianCitizen.toString());
				throw e;
			}
			
			try {
				if(scriptItalianCitizen.length() > 10)
					stmOTpCC.executeUpdate(scriptItalianCitizen.toString());
			}
			catch(SQLException e) {
				System.out.println("ERROR: Error inserting into ITALIAN_CITIZEN (OTpCC). [FillPersonn.fillPerson()]");
				System.out.println(scriptItalianCitizen.toString());
				throw e;
			}
			
			try {
				if(scriptChild.length() > 10)
					stmOTpCC.executeUpdate(scriptChild.toString());
			}
			catch(SQLException e) {
				System.out.println("ERROR: Error inserting into CHILD (OTpCC). [FillPersonn.fillPerson()]");
				System.out.println(scriptChild.toString());
				throw e;
			}
			
			try {
				if(scriptAdult.length() > 10)
					stmOTpCC.executeUpdate(scriptAdult.toString());
			}
			catch(SQLException e) {
				System.out.println("ERROR: Error inserting into ADULT (OTpCC). [FillPersonn.fillPerson()]");
				System.out.println(scriptAdult.toString());
				throw e;
			}
			
			try {
				if(scriptEmployee.length() > 10)
					stmOTpCC.executeUpdate(scriptEmployee.toString());
			}
			catch(SQLException e) {
				System.out.println("ERROR: Error inserting into EMPLOYEE (OTpCC). [FillPersonn.fillPerson()]");
				System.out.println(scriptEmployee.toString());
				throw e;
			}
			
			try {
				if(scriptPersonalCustomer.length() > 10)
					stmOTpCC.executeUpdate(scriptPersonalCustomer.toString());
			}
			catch(SQLException e) {
				System.out.println("ERROR: Error inserting into PERSONAL_CUSTOMER (OTpCC). [FillPersonn.fillPerson()]");
				System.out.println(scriptPersonalCustomer.toString());
				throw e;
			}
			
			try {
				stmOTpK.executeUpdate(scriptOTpKPerson.toString());
			}
			catch(SQLException e) {
				System.out.println("ERROR: Error inserting into PERSON (OTpK). [FillPersonn.fillPerson()]");
				System.out.println(scriptOTpKPerson.toString());
				throw e;
			}
			
			try{
				stmOTpK.executeUpdate(scriptOTpKNationality.toString());
			}
			catch(SQLException e) {
				System.out.println("ERROR: Error inserting into NATIONALITY (OTpK). [FillPersonn.fillPerson()]");
				System.out.println(scriptOTpKNationality.toString());
				throw e;
			}
			quantityPerson--;
		}
		
		System.out.println("STATUS ---> person completed.");
	}
	
	private void pullScriptForPerson() throws SQLException {
		ArrayList<Person> array = Factory.getArrayOfPerson(param);
		scriptPerson = new StringBuilder();
		scriptBrazilianCitizen = new StringBuilder();
		scriptItalianCitizen = new StringBuilder();
		scriptChild = new StringBuilder();
		scriptAdult = new StringBuilder();
		scriptEmployee = new StringBuilder();
		scriptPersonalCustomer = new StringBuilder();
		scriptOTpKPerson = new StringBuilder();
		scriptOTpKNationality = new StringBuilder();
		boolean firstPerson = true;
		boolean firstBrazilianCitizen = true;
		boolean firstItalianCitizen = true;
		boolean firstChild = true;
		boolean firstAdult = true;
		boolean firstEmployee = true;
		boolean firstPersonalCustomer = true;
		boolean firstOTpK = true;
		boolean firstNationality = true;
		
		for (Person person : array) {
			//*******************************************
			//** SCRIPT FOR ONE TABLE PER CONCRETE CLASS
			//*******************************************
			// person
			if(firstPerson) {
				scriptPerson.append("INSERT INTO person (person_id, name, birth_date) VALUES (");
				scriptPerson.append(pkPerson);
				scriptPerson.append(",'");
				scriptPerson.append(person.getName());
				scriptPerson.append("','");
				scriptPerson.append(person.getBirthDate().toString());
				scriptPerson.append("')\n     ");
				firstPerson = false;
			}else {
				scriptPerson.append(", (");
				scriptPerson.append(pkPerson);
				scriptPerson.append(",'");
				scriptPerson.append(person.getName());
				scriptPerson.append("','");
				scriptPerson.append(person.getBirthDate().toString());
				scriptPerson.append("')\n     ");
			}
			
			//BrazilianCitizen
			if(		person.getNationality() == Nationality.BrazilianCitizen ||
					person.getNationality() == Nationality.BrazilianItalianCitizen){
				if(firstBrazilianCitizen) {
					scriptBrazilianCitizen.append("INSERT INTO brazilian_citizen (person_id, rg) VALUES (");
					scriptBrazilianCitizen.append(pkPerson);
					scriptBrazilianCitizen.append(",");
					scriptBrazilianCitizen.append(person.getRG());
					scriptBrazilianCitizen.append(")\n     ");
					firstBrazilianCitizen = false;
				}else {
					scriptBrazilianCitizen.append(", (");
					scriptBrazilianCitizen.append(pkPerson);
					scriptBrazilianCitizen.append(",");
					scriptBrazilianCitizen.append(person.getRG());
					scriptBrazilianCitizen.append(")\n     ");
				}
				brazilians.add(pkPerson);
			}
			
			//ItalianCitizen
			if(		person.getNationality() == Nationality.ItalianCitizen ||
					person.getNationality() == Nationality.BrazilianItalianCitizen){
				if(firstItalianCitizen) {
					scriptItalianCitizen.append("INSERT INTO italian_citizen (person_id, ci) VALUES (");
					scriptItalianCitizen.append(pkPerson);
					scriptItalianCitizen.append(",");
					scriptItalianCitizen.append(person.getCI());
					scriptItalianCitizen.append(")\n     ");
					firstItalianCitizen = false;
				}else {
					scriptItalianCitizen.append(", (");
					scriptItalianCitizen.append(pkPerson);
					scriptItalianCitizen.append(",");
					scriptItalianCitizen.append(person.getCI());
					scriptItalianCitizen.append(")\n     ");
				}
				italians.add(pkPerson);
			}
			
			// child
			if(person.getLifePhase() == LifePhase.Child){
				if(firstChild) {
					scriptChild.append("INSERT INTO child (person_id) VALUES (");
					scriptChild.append(pkPerson);
					scriptChild.append(")\n     ");
					firstChild = false;
				}else {
					scriptChild.append(", (");
					scriptChild.append(pkPerson);
					scriptChild.append(")\n     ");
				}
				childs.add(pkPerson);
			}
			
			// adult
			if(person.getLifePhase() == LifePhase.Adult){
				if(firstAdult) {
					scriptAdult.append("INSERT INTO adult (person_id) VALUES (");
					scriptAdult.append(pkPerson);
					scriptAdult.append(")\n     ");
					firstAdult = false;
				}else {
					scriptAdult.append(", (");
					scriptAdult.append(pkPerson);
					scriptAdult.append(")\n     ");
				}
				adults.add(pkPerson);
			}

			if(person.isPersonalCustomer()){
				if(firstPersonalCustomer) {
					scriptPersonalCustomer.append("INSERT INTO personal_customer (person_id, credit_rating, credit_card) VALUES ( ");
					scriptPersonalCustomer.append(pkPerson);
					scriptPersonalCustomer.append(",");
					scriptPersonalCustomer.append(person.getCreditRating());
					scriptPersonalCustomer.append(",'");
					scriptPersonalCustomer.append(person.getCreditCard());
					scriptPersonalCustomer.append("')\n     ");
					firstPersonalCustomer = false;
				}else {
					scriptPersonalCustomer.append(", (");
					scriptPersonalCustomer.append(pkPerson);
					scriptPersonalCustomer.append(",");
					scriptPersonalCustomer.append(person.getCreditRating());
					scriptPersonalCustomer.append(",'");
					scriptPersonalCustomer.append(person.getCreditCard());
					scriptPersonalCustomer.append("')\n     ");
				}
				customers.add(pkPerson);
			}
			
			if(person.isEmployee()){
				if(firstEmployee) {
					scriptEmployee.append("INSERT INTO employee (person_id) VALUES ( ");
					scriptEmployee.append(pkPerson);
					scriptEmployee.append(")\n     ");
					firstEmployee = false;
				}else {
					scriptEmployee.append(", (");
					scriptEmployee.append(pkPerson);
					scriptEmployee.append(")\n     ");
				}
				employees.add(pkPerson);
			}
			
			//*******************************************
			//** SCRIPT FOR ONE TABLE PER KIND
			//*******************************************
			if(firstOTpK) {
				scriptOTpKPerson.append("INSERT INTO person (person_id, name, birth_date, rg, ci, credit_rating, credit_card, is_personal_customer, is_employee, life_phase_enum) VALUES (");
				
				scriptOTpKPerson.append(pkPerson);
				scriptOTpKPerson.append(",'");
				scriptOTpKPerson.append(person.getName()); //name
				scriptOTpKPerson.append("','");
				scriptOTpKPerson.append(person.getBirthDate().toString()); //birth_date
				scriptOTpKPerson.append("',");
				scriptOTpKPerson.append(person.getRG());//rg
				scriptOTpKPerson.append(",");
				scriptOTpKPerson.append(person.getCI());//ci
				scriptOTpKPerson.append(",");
				scriptOTpKPerson.append(person.getCreditRating());//credit_rating
				scriptOTpKPerson.append(",'");
				scriptOTpKPerson.append(person.getCreditCard());//credit_card
				scriptOTpKPerson.append("',");
				scriptOTpKPerson.append(person.isPersonalCustomer());//is_personal_customer
				scriptOTpKPerson.append(",");
				scriptOTpKPerson.append(person.isEmployee());//is_employee
				scriptOTpKPerson.append(",'");
				scriptOTpKPerson.append(person.getLifePhase().getValue());//life_phase_enum
				scriptOTpKPerson.append("')\n     ");
				
				if(		person.getNationality() == Nationality.BrazilianCitizen ||
						person.getNationality() == Nationality.BrazilianItalianCitizen) {
					scriptOTpKNationality.append("insert into nationality (nationality_id, person_id, nationality_enum) values (");
					scriptOTpKNationality.append(pkNationality);
					scriptOTpKNationality.append(",");
					scriptOTpKNationality.append(pkPerson);
					scriptOTpKNationality.append(",'");
					scriptOTpKNationality.append(Nationality.BrazilianCitizen);
					scriptOTpKNationality.append("')\n    ");
					pkNationality++;
					firstNationality = false;
				}
				if(		person.getNationality() == Nationality.ItalianCitizen ||
						person.getNationality() == Nationality.BrazilianItalianCitizen) {
					if(firstNationality) {
						scriptOTpKNationality.append("insert into nationality (nationality_id, person_id, nationality_enum) values (");
						scriptOTpKNationality.append(pkNationality);
						scriptOTpKNationality.append(",");
						scriptOTpKNationality.append(pkPerson);
						scriptOTpKNationality.append(",'");
						scriptOTpKNationality.append(Nationality.ItalianCitizen);
						scriptOTpKNationality.append("')\n     ");
						pkNationality++;
					}else {
						scriptOTpKNationality.append(", (");
						scriptOTpKNationality.append(pkNationality);
						scriptOTpKNationality.append(",");
						scriptOTpKNationality.append(pkPerson);
						scriptOTpKNationality.append(",'");
						scriptOTpKNationality.append(Nationality.ItalianCitizen);
						scriptOTpKNationality.append("')\n     ");
						pkNationality++;
					}
				}
				firstOTpK = false;
			}else {
				scriptOTpKPerson.append(", (");
				scriptOTpKPerson.append(pkPerson);
				scriptOTpKPerson.append(",'");
				scriptOTpKPerson.append(person.getName()); //name
				scriptOTpKPerson.append("','");
				scriptOTpKPerson.append(person.getBirthDate().toString()); //birth_date
				scriptOTpKPerson.append("',");
				scriptOTpKPerson.append(person.getRG());//rg
				scriptOTpKPerson.append(",");
				scriptOTpKPerson.append(person.getCI());//ci
				scriptOTpKPerson.append(",");
				scriptOTpKPerson.append(person.getCreditRating());//credit_rating
				scriptOTpKPerson.append(",'");
				scriptOTpKPerson.append(person.getCreditCard());//credit_card
				scriptOTpKPerson.append("',");
				scriptOTpKPerson.append(person.isPersonalCustomer());//is_personal_customer
				scriptOTpKPerson.append(",");
				scriptOTpKPerson.append(person.isEmployee());//is_employee
				scriptOTpKPerson.append(",'");
				scriptOTpKPerson.append(person.getLifePhase().getValue());//life_phase_enum
				scriptOTpKPerson.append("')\n     ");
				
				
				if(		person.getNationality() == Nationality.BrazilianCitizen || 
						person.getNationality() == Nationality.BrazilianItalianCitizen) {
					scriptOTpKNationality.append(", (");
					scriptOTpKNationality.append(pkNationality);
					scriptOTpKNationality.append(",");
					scriptOTpKNationality.append(pkPerson);
					scriptOTpKNationality.append(",'");
					scriptOTpKNationality.append(Nationality.BrazilianCitizen);
					scriptOTpKNationality.append("')\n    ");
					pkNationality++;
				}
				if(		person.getNationality() == Nationality.ItalianCitizen ||
						person.getNationality() == Nationality.BrazilianItalianCitizen) {
					scriptOTpKNationality.append(", (");
					scriptOTpKNationality.append(pkNationality);
					scriptOTpKNationality.append(",");
					scriptOTpKNationality.append(pkPerson);
					scriptOTpKNationality.append(",'");
					scriptOTpKNationality.append(Nationality.ItalianCitizen);
					scriptOTpKNationality.append("')\n     ");
					pkNationality++;
				}
			}
			pkPerson++;			
		}
		scriptPerson.append(";");
		scriptBrazilianCitizen.append(";");
		scriptItalianCitizen.append(";");
		scriptChild.append(";");
		scriptAdult.append(";");
		scriptEmployee.append(";");
		scriptPersonalCustomer.append(";");
		scriptOTpKPerson.append(";");
		scriptOTpKNationality.append(";");
	}
}
