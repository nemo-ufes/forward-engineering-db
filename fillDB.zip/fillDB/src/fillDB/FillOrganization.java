package fillDB;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import classes.Organization;
import classes.OrganizationType;
import factory.Factory;

public class FillOrganization {
	
	private Parameters param;
	private int pkOrganization;
	private Statement stmOTpCC;
	private Statement stmOTpK;
	
	private StringBuilder scriptOrganization;
	private StringBuilder scriptHospital;
	private StringBuilder scriptSchool;
	private StringBuilder scriptContractor;
	private StringBuilder scriptCorporateCustomer;
	private StringBuilder scriptOTpK;
	
	private ArrayList<Integer> organizations;
	private ArrayList<Integer> contractors;
	private ArrayList<Integer> hospitals;
	private ArrayList<Integer> schools;
	private ArrayList<Integer> customers;
	

	public ArrayList<Integer> getOrganizationsID(){
		return organizations;
	}
	
	public ArrayList<Integer> getContractorsID(){
		return contractors;
	}
	
	public ArrayList<Integer> getHospitalsID(){
		return hospitals;
	}
	
	public ArrayList<Integer> getSchoolsID(){
		return schools;
	}
	
	public ArrayList<Integer> getCustomersID(){
		return customers;
	}
	
	public FillOrganization(Statement stmOTpCC, Statement stmOTpK, Parameters param) throws SQLException{
		this.param = param;
		this.stmOTpCC = stmOTpCC;
		this.stmOTpK = stmOTpK;
		
		organizations = new ArrayList<Integer>();
		contractors = new ArrayList<Integer>();
		hospitals = new ArrayList<Integer>();
		schools = new ArrayList<Integer>();
		customers = new ArrayList<Integer>();
		
		try {
			ResultSet rs = this.stmOTpCC.executeQuery("select max(organization_id) next_id from organization");
			rs.next();
			pkOrganization = rs.getInt(1)+1;
		}
		catch(Exception e) {
			System.out.println("ERROR: Error finding first PK for organization. [FillOrganization]");
			throw e;
		}
	}
	
	//********************************
	//***** Organization
	//********************************
	public void fill( ) throws SQLException {
		if(param.getAmtOrganization() > 0) {
			fillOrganization();
		}else {
			putArrays();
		}
	}
	
	private void putArrays() throws SQLException {
		ResultSet rs;
		
		System.out.println("STATUS ---> Getting organization.");
		rs = this.stmOTpCC.executeQuery("select organization_id from organization order by organization_id");
		while(rs.next()) {
			organizations.add(rs.getInt(1));
		}
		rs.close();
		
		System.out.println("STATUS ---> Getting contractor.");
		rs = this.stmOTpCC.executeQuery("select organization_id from contractor order by organization_id");
		while(rs.next()) {
			contractors.add(rs.getInt(1));
		}
		rs.close();

		System.out.println("STATUS ---> Getting primary_school.");
		rs = this.stmOTpCC.executeQuery("select organization_id from primary_school order by organization_id");
		while(rs.next()) {
			schools.add(rs.getInt(1));
		}
		rs.close();
		
		System.out.println("STATUS ---> Getting corportate_customer.");
		rs = this.stmOTpCC.executeQuery("select organization_id from corporate_customer order by organization_id");
		while(rs.next()) {
			customers.add(rs.getInt(1));
		}
		rs.close();
	}
	
	private void fillOrganization() throws SQLException {
		int quantityOrganization = param.getAmtOrganization();
		System.out.println("STATUS ---> Filling organization.");
		
		while (quantityOrganization > 0) {
			
			pullScriptForOrganization( );
			
			try {
				if(scriptOrganization.length() > 10)
					stmOTpCC.executeUpdate(scriptOrganization.toString());
			}
			catch(SQLException e) {
				System.out.println("ERROR: Error inserting into ORGANIZATION (OTpCC). [FillOrganization.fillOrganization]");
				System.out.println(scriptOrganization.toString());
				throw e;
			}
			
			try {				
				if(scriptHospital.length() > 10)
					stmOTpCC.executeUpdate(scriptHospital.toString());
			}
			catch(SQLException e) {
				System.out.println("ERROR: Error inserting into HOSPITAL (OTpCC). [FillOrganization.fillOrganization]");
				System.out.println(scriptHospital.toString());
				throw e;
			}
			
			try {				
				if(scriptSchool.length() > 10)
					stmOTpCC.executeUpdate(scriptSchool.toString());
			}
			catch(SQLException e) {
				System.out.println("ERROR: Error inserting into SCHOOL (OTpCC). [FillOrganization.fillOrganization]");
				System.out.println(scriptSchool.toString());
				throw e;
			}
			
			try {				
				if(scriptCorporateCustomer.length() > 10)
					stmOTpCC.executeUpdate(scriptCorporateCustomer.toString());
			}
			catch(SQLException e) {
				System.out.println("ERROR: Error inserting into CORPORATE_CUSTOMER (OTpCC). [FillOrganization.fillOrganization]");
				System.out.println(scriptCorporateCustomer.toString());
				throw e;
			}
			
			try {				
				if(scriptContractor.length() > 10)
					stmOTpCC.executeUpdate(scriptContractor.toString());
			}
			catch(SQLException e) {
				System.out.println("ERROR: Error inserting into CONTRACTOR (OTpCC). [FillOrganization.fillOrganization]");
				System.out.println(scriptContractor.toString());
				throw e;
			}
			
			
			try {
				if(scriptOTpK.length() > 10)
					stmOTpK.executeUpdate(scriptOTpK.toString());
			}
			catch(SQLException e) {
				System.out.println("ERROR: Error inserting into organization (OTpK). [FillOrganization.fillOrganization]");
				System.out.println(scriptOTpK.toString());
				throw e;
			}
			
			quantityOrganization--;
		}
		System.out.println("STATUS ---> organization completed.");
	}
	
	private void pullScriptForOrganization( ) {
		ArrayList<Organization> array = Factory.getArrayOfOrgaization(param);
		scriptOrganization = new StringBuilder();
		scriptHospital = new StringBuilder();
		scriptSchool = new StringBuilder();
		scriptContractor = new StringBuilder();
		scriptCorporateCustomer = new StringBuilder();
		scriptOTpK = new StringBuilder();
		boolean firstOrganization = true;
		boolean firstHospital = true;
		boolean firstSchool = true;
		boolean firstCorporateCustomer = true;
		boolean firstContractor = true;
		boolean firstOTpK = true;
		
		for (Organization organization : array) {
			//*******************************************
			//** SCRIPT FOR ONE TABLE PER CONCRETE CLASS
			//*******************************************
			// organization
			if(firstOrganization) {
				scriptOrganization.append("INSERT INTO organization (organization_id, name, address) VALUES (");
				scriptOrganization.append(pkOrganization);
				scriptOrganization.append(",'");
				scriptOrganization.append(organization.getName());
				scriptOrganization.append("','");
				scriptOrganization.append(organization.getAddress());
				scriptOrganization.append("')\n     ");
				firstOrganization = false;
			}else {
				scriptOrganization.append(", (");
				scriptOrganization.append(pkOrganization);
				scriptOrganization.append(",'");
				scriptOrganization.append(organization.getName());
				scriptOrganization.append("','");
				scriptOrganization.append(organization.getAddress());
				scriptOrganization.append("')\n     ");
			}
			
			//hospital
			if(organization.getOrganizationType() == OrganizationType.Hospital){
				if(firstHospital) {
					scriptHospital.append("INSERT INTO hospital (organization_id, capacity) VALUES (");
					scriptHospital.append(pkOrganization);
					scriptHospital.append(",");
					scriptHospital.append(organization.getCapacity());
					scriptHospital.append(")\n     ");
					firstHospital = false;
				}else {
					scriptHospital.append(", (");
					scriptHospital.append(pkOrganization);
					scriptHospital.append(",");
					scriptHospital.append(organization.getCapacity());
					scriptHospital.append(")\n     ");
				}
				hospitals.add(pkOrganization);
			}
			
			// primary_school
			if(organization.getOrganizationType() == OrganizationType.PrimarySchool){
				if(firstSchool) {
					scriptSchool.append("INSERT INTO primary_school (organization_id, playground_size) VALUES (");
					scriptSchool.append(pkOrganization);
					scriptSchool.append(",");
					scriptSchool.append(organization.getPlaygroundSize());
					scriptSchool.append(")\n     ");
					firstSchool = false;
				}else {
					scriptSchool.append(", (");
					scriptSchool.append(pkOrganization);
					scriptSchool.append(",");
					scriptSchool.append(organization.getPlaygroundSize());
					scriptSchool.append(")\n     ");
				}
				schools.add(pkOrganization);
			}
			
			if(organization.isCorporateCustomer()){
				if(firstCorporateCustomer) {
					scriptCorporateCustomer.append("INSERT INTO corporate_customer (organization_id, credit_rating, credit_limit) VALUES ( ");
					scriptCorporateCustomer.append(pkOrganization);
					scriptCorporateCustomer.append(",");
					scriptCorporateCustomer.append(organization.getCreditRating());
					scriptCorporateCustomer.append(",");
					scriptCorporateCustomer.append(organization.getCreditLimit());
					scriptCorporateCustomer.append(")\n     ");
					firstCorporateCustomer = false;
				}else {
					scriptCorporateCustomer.append(", (");
					scriptCorporateCustomer.append(pkOrganization);
					scriptCorporateCustomer.append(",");
					scriptCorporateCustomer.append(organization.getCreditRating());
					scriptCorporateCustomer.append(",");
					scriptCorporateCustomer.append(organization.getCreditLimit());
					scriptCorporateCustomer.append(")\n     ");
				}
				customers.add(pkOrganization);
			}
			
			if(organization.isContractor()){
				if(firstContractor) {
					scriptContractor.append("INSERT INTO contractor (organization_id) VALUES ( ");
					scriptContractor.append(pkOrganization);
					scriptContractor.append(")\n     ");
					firstContractor = false;
				}else {
					scriptContractor.append(", (");
					scriptContractor.append(pkOrganization);
					scriptContractor.append(")\n     ");
				}
				contractors.add(pkOrganization);
			}
			
			//*******************************************
			//** SCRIPT FOR ONE TABLE PER KIND
			//*******************************************
			if(firstOTpK) {
				scriptOTpK.append("INSERT INTO organization (organization_id, name, address, credit_rating, credit_limit, is_corporate_customer, playground_size, capacity, is_contractor, organization_type_enum) VALUES (");
				
				scriptOTpK.append(pkOrganization);
				scriptOTpK.append(",'");
				scriptOTpK.append(organization.getName()); //name
				scriptOTpK.append("','");
				scriptOTpK.append(organization.getAddress()); //address
				scriptOTpK.append("',");
				scriptOTpK.append(organization.getCreditRating());//credit_rating
				scriptOTpK.append(",");
				scriptOTpK.append(organization.getCreditLimit());//credit_limit
				scriptOTpK.append(",");
				scriptOTpK.append(organization.isCorporateCustomer());//is_corporate_customer
				scriptOTpK.append(",");
				scriptOTpK.append(organization.getPlaygroundSize());//plyground_size
				scriptOTpK.append(",");
				scriptOTpK.append(organization.getCapacity());//capacity
				scriptOTpK.append(",");
				scriptOTpK.append(organization.isContractor());//is_contractor
				scriptOTpK.append(",'");
				scriptOTpK.append(organization.getOrganizationType().getValue());//organization_type_enum
				scriptOTpK.append("')\n     ");
				firstOTpK = false;
			}else {
				scriptOTpK.append(", (");
				scriptOTpK.append(pkOrganization);
				scriptOTpK.append(",'");
				scriptOTpK.append(organization.getName()); //name
				scriptOTpK.append("','");
				scriptOTpK.append(organization.getAddress()); //address
				scriptOTpK.append("',");
				scriptOTpK.append(organization.getCreditRating());//credit_rating
				scriptOTpK.append(",");
				scriptOTpK.append(organization.getCreditLimit());//credit_limit
				scriptOTpK.append(",");
				scriptOTpK.append(organization.isCorporateCustomer());//is_corporate_customer
				scriptOTpK.append(",");
				scriptOTpK.append(organization.getPlaygroundSize());//plyground_size
				scriptOTpK.append(",");
				scriptOTpK.append(organization.getCapacity());//capacity
				scriptOTpK.append(",");
				scriptOTpK.append(organization.isContractor());//is_contractor
				scriptOTpK.append(",'");
				scriptOTpK.append(organization.getOrganizationType().getValue());//organization_type_enum
				scriptOTpK.append("')\n     ");
			}
			
			organizations.add(pkOrganization);
			pkOrganization++;
		}
		scriptOrganization.append(";");
		scriptHospital.append(";");
		scriptSchool.append(";");
		scriptCorporateCustomer.append(";");
		scriptContractor.append(";");
		scriptOTpK.append(";");
	}
}
