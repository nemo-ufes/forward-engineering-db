package classes;

public enum Nationality {
	BrazilianCitizen("BrazilianCitizen"),
	ItalianCitizen("ItalianCitizen"),
	BrazilianItalianCitizen("BrazilianItalianCitizen");
	
	private final String description;
	
	Nationality(String desc){
		description = desc;
	}
	
	public String getValue(){
		return description;
	}
}
