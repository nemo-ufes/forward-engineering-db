package classes;

public class Person {
	private String name;
	private String birthDate;
	private String RG;
	private String CI;
	private double creditRating;
	private String creditCard;
	private boolean isPersonalCustomer;
	private boolean isEmployee;
	private LifePhase lifePhase;
	private Nationality nationality;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBirthDate() {
		return birthDate;
	}
	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}
	public String getRG() {
		return RG;
	}
	public void setRG(String rG) {
		RG = rG;
	}
	public String getCI() {
		return CI;
	}
	public void setCI(String cI) {
		CI = cI;
	}
	public double getCreditRating() {
		return creditRating;
	}
	public void setCreditRating(double creditRating) {
		this.creditRating = creditRating;
	}
	public String getCreditCard() {
		return creditCard;
	}
	public void setCreditCard(String creditCard) {
		this.creditCard = creditCard;
	}
	public boolean isPersonalCustomer() {
		return isPersonalCustomer;
	}
	public void setPersonalCustomer(boolean isPersonalCustomer) {
		this.isPersonalCustomer = isPersonalCustomer;
	}
	public boolean isEmployee() {
		return isEmployee;
	}
	public void setEmployee(boolean isEmployee) {
		this.isEmployee = isEmployee;
	}
	public LifePhase getLifePhase() {
		return lifePhase;
	}
	public void setLifePhase(LifePhase lifePhase) {
		this.lifePhase = lifePhase;
	}
	public Nationality getNationality() {
		return nationality;
	}
	public void setNationality(Nationality nationality) {
		this.nationality = nationality;
	}

}
