package classes;

public class SupplyContract {

}
