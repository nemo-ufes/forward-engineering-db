package classes;

public enum LifePhase {
	Child("Child"),
	Adult("Adult");
	
	private final String description;
	
	LifePhase(String desc){
		description = desc;
	}
	
	public String getValue(){
		return description;
	}
}
