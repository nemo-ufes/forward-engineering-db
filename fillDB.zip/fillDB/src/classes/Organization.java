package classes;

public class Organization {
	private String name;
	private String address;
	private double creditRating;
	private double creditLimit;
	private boolean isCorporateCustomer;
	private int playgroundSize;
	private int capacity;
	private boolean isContractor;
	private OrganizationType organizationType;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getCreditRating() {
		return creditRating;
	}
	public void setCreditRating(double creditRating) {
		this.creditRating = creditRating;
	}
	public double getCreditLimit() {
		return creditLimit;
	}
	public void setCreditLimit(double creditLimit) {
		this.creditLimit = creditLimit;
	}
	public boolean isCorporateCustomer() {
		return isCorporateCustomer;
	}
	public void setCorporateCustomer(boolean isCorporateCustomer) {
		this.isCorporateCustomer = isCorporateCustomer;
	}
	public int getPlaygroundSize() {
		return playgroundSize;
	}
	public void setPlaygroundSize(int playgroundSize) {
		this.playgroundSize = playgroundSize;
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	public boolean isContractor() {
		return isContractor;
	}
	public void setContractor(boolean isContractor) {
		this.isContractor = isContractor;
	}
	public OrganizationType getOrganizationType() {
		return organizationType;
	}
	public void setOrganizationType(OrganizationType organizationType) {
		this.organizationType = organizationType;
	}
}
