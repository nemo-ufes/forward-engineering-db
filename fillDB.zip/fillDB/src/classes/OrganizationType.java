package classes;

public enum OrganizationType {
	Hospital("Hospital"),
	PrimarySchool("PrimarySchool");
	
	private final String description;
	
	OrganizationType(String desc){
		description = desc;
	}
	
	public String getValue(){
		return description;
	}
}
