package factory;

import java.util.ArrayList;

import classes.Organization;
import classes.Person;
import fillDB.Parameters;

public class Factory {
	
	
	public static ArrayList<Organization> getArrayOfOrgaization(Parameters param){
		ArrayList<Organization> array = new ArrayList<Organization>();
		
		for(int i = 0; i < param.getAmountOfInsertPerTransaction(); i++) {
			array.add(FactoryOrganization.getOrganization(param));
		}
		
		return array;
	}

	public static ArrayList<Person> getArrayOfPerson(Parameters param) {
		ArrayList <Person>array = new ArrayList<Person>();
		
		for(int i = 0; i < param.getAmountOfInsertPerTransaction(); i++) {
			array.add(FactoryPerson.getPerson(param));
		}
		
		return array;
	}
}
