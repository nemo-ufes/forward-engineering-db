package factory;

import classes.LifePhase;
import classes.Nationality;
import classes.Person;
import fillDB.Parameters;

public class FactoryPerson {

	public static Person getPerson(Parameters param) {
		Person person = new Person();
		
		person.setName(getName());
		person.setBirthDate(getBirthDate()); 
		person.setNationality(getNationality(param));
		person.setRG(getRG(person));
		person.setCI(getCI(person));
		person.setCreditRating(getCreditRating());
		person.setCreditCard(getCreditCard());
		person.setLifePhase(getLifePhase(param));
		person.setPersonalCustomer(getIsPersonalCustomer(person, param));
		person.setEmployee(getIsEmployee(person.getLifePhase(), param));
		
		return person;
	}
	
	private static String getName() {
		return Util.getInstance().getRandomString(5);
	}
	
	private static String getBirthDate() {
		int year = Util.getInstance().getRandomInt(80) + 1930;//1930..2009
		int month = Util.getInstance().getRandomInt(12) + 1;
		int day = Util.getInstance().getRandomInt(28) + 1;//1..28
		
		String smonth = "00"+month;
		smonth = smonth.substring(smonth.length() - 2);//month with 2 digits
		
		String sday = "00"+day;
		sday = sday.substring(sday.length() - 2);// day with 2 digits
		
		return year + smonth + sday;
	}
	
	private static String getRG(Person person) {
		if(		person.getNationality() == Nationality.BrazilianCitizen ||
				person.getNationality() == Nationality.BrazilianItalianCitizen) {
			int result = Util.getInstance().getRandomInt(999999999);
			return String.valueOf(result);
		}
		else return null;
	}
	
	private static String getCI(Person person) {
		if(		person.getNationality() == Nationality.ItalianCitizen ||
				person.getNationality() == Nationality.BrazilianItalianCitizen) {
			int result = Util.getInstance().getRandomInt(999999999);
			return String.valueOf(result);
		}
		else return null;
	}
	
	private static double getCreditRating() {
		return Util.getInstance().getRandomInt(101);//0..100
	}
	
	private static String getNumber(int num) {
		String aux = "000"+num;
		int l = aux.length();
		return aux.substring(l-3, l);
	}
	
	private static String getCreditCard() {
		String result = "";
		int num;
		
		num = Util.getInstance().getRandomInt(1000);
		result += getNumber(num)+".";
		
		num = Util.getInstance().getRandomInt(1000);
		result += getNumber(num)+".";
		
		num = Util.getInstance().getRandomInt(1000);
		result += getNumber(num)+".";
		
		num = Util.getInstance().getRandomInt(1000);
		result += getNumber(num);
		
		return result;
	}
	
	private static boolean getIsPersonalCustomer(Person person, Parameters param) {
		if(person.getLifePhase() == LifePhase.Child)
			return false;
		
		int prob = Util.getInstance().getRandomInt(100);//0..99
		
		if(prob <= param.getPctPersonalCustomer())
			return true;
		else return false;
	}
	
	private static boolean getIsEmployee(LifePhase phase, Parameters param) {
		int prob = Util.getInstance().getRandomInt(101);//0..100
		
		if(prob <= param.getPctEmployee() && phase != LifePhase.Child)
			return true;
		else return false;
	}
	
	private static LifePhase getLifePhase(Parameters param) {
		int prob = Util.getInstance().getRandomInt(100);//0..99
		
		if(prob <= param.getPctAdult())
			return LifePhase.Adult;
		else return LifePhase.Child;
		
	}
	
	private static Nationality getNationality(Parameters param) {
		int prob = Util.getInstance().getRandomInt(101);//0..100
		
		if(prob < param.getPctBrazilianCitizen())
			return Nationality.BrazilianCitizen;
		if(prob >= param.getPctBrazilianCitizen() && prob < (param.getPctBrazilianCitizen() + param.getPctItalianCitizen()))
			return Nationality.ItalianCitizen;
		return Nationality.BrazilianItalianCitizen;
	}
}
