package factory;

import classes.Organization;
import classes.OrganizationType;
import fillDB.Parameters;

public class FactoryOrganization {

	public static Organization getOrganization(Parameters param) {
		Organization organization = new Organization();
		
		organization.setName(getName());
		organization.setAddress(getAddress());
		organization.setCreditRating(getCreditRating());
		organization.setCreditLimit(getCreditLimit());
		organization.setCorporateCustomer(getIsCorporateCustomer(param));
		organization.setPlaygroundSize(getPlaygroundSize());
		organization.setCapacity(getCapacity());
		organization.setContractor(getIsContractor(param));
		organization.setOrganizationType(getOrganizaionType(param));
		
		return organization;
	}
	
	private static String getName() {
		return Util.getInstance().getRandomString(6);
	}
	
	private static String getAddress() {
		return Util.getInstance().getRandomString(10);
	}
	
	private static double getCreditRating() {
		return Util.getInstance().getRandomInt(101);//0..100
	}
	
	private static double getCreditLimit() {
		int rate = Util.getInstance().getRandomInt(999);
		return rate * 1000;
	}
	
	private static boolean getIsCorporateCustomer(Parameters param) {
		int prob = Util.getInstance().getRandomInt(100);//0..99
		
		if(prob < param.getPctCorporateCustomer())
			return true;
		else return false;
	}
	
	private static int getPlaygroundSize() {
		return Util.getInstance().getRandomInt(9999) + 1;
	}
	
	private static int getCapacity() {
		return Util.getInstance().getRandomInt(999) + 1;
	}
	
	private static boolean getIsContractor(Parameters param) {
		int prob =  Util.getInstance().getRandomInt(100);//0..99
		
		if(prob < param.getPctContractor())
			return true;
		else return false;
		
	}
	
	private static OrganizationType getOrganizaionType(Parameters param) {
		int prob =  Util.getInstance().getRandomInt(100);//0..99
		
		if(prob <= param.getPctHospitalOrganization())
			return OrganizationType.Hospital;
		else return OrganizationType.PrimarySchool;
		
	}
}
