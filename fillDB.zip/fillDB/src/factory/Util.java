package factory;

import java.util.Random;

public class Util {
	
	private static Util util;
	private static Random random;
	
	private Util() {
		random = new Random();
	}
	
	public static Util getInstance() {
		if(util == null)
			util = new Util();
		
		return util;
	}

	
	public String getRandomString(int lenght) {
		int num = 0;
		StringBuilder name = new StringBuilder();
		
		while( lenght > 1) {
			num = random.nextInt(27);// 0..26; 
			
			if(num > 0) {//not show 0.
				name.append( (char) (num+64));
			}
			lenght--;
		}
		//to have at least on character
		num = random.nextInt(26) + 1;//1..26
		name.append( (char) (num+64) );
		
		return name.toString();
	}
	
	public int getRandomInt(int lenght) {
		return random.nextInt(lenght);
	}
	
}
